#include "pic24f.h"
#include "uart.h"
#include "monitor.h"
#include "diskio.h"
#include "ff.h"
#include "ffhelper.h"
#include "taskFlyport.h"
#include "grovelib.h"

void FlyportTask()
{
		
#ifdef INTERRUPT
	
	PR4 = 16000;
	T4CONbits.TON=1;
	_T4IE=1;
	T4CONbits.TCKPS0=0;
	T4CONbits.TCKPS1=0;
#endif

#if _USE_LFN
	Finfo.lfname = Lfname;
	Finfo.lfsize = sizeof(Lfname);
#endif
	void *board = new(GroveNest);
 
	IOInit( p19, out);
	IOInit(p2, UART2RX);
    IOInit(p4, UART2TX);
	
	vTaskDelay(50);
	if ( f_mount(0, &Fatfs) == FR_OK)
		UARTWrite(1, "SD software module initialized!\r\n");
	else{	
		UARTWrite(1, "SD software module NOT initialized!\r\n");
		while(1){
			IOPut( 19,toggle);
			DelayMs(1000);
		}
	}
	
	disk_initialize(0);
	vTaskDelay(20);
	if (!disk_status(0))
	{
		UARTWrite(1, "SD card initialized and ready!\r\n");
	}
	else{
		UARTWrite(1,"Error in initializing SD card\r\n");
		while(1){
			IOPut( 19,toggle);
			DelayMs(1000);
		}
	}
	
	UARTWrite(1, "Get new photo!\r\n");
		
	save_photo_to_sd();
	vTaskDelay(50);
	
	while(1){
		
		vTaskDelay(100);
	}
	
}