#include "HWlib.h"

#include "pic24f.h"
#include "uart.h"
#include "diskio.h"
#include "ff.h"
#include <string.h>

#ifndef _FATFSHELPER
#define _FATFSHELPER	

//#define _FATFS_USE_UDP_BUFFER

#if defined (_FATFS_USE_UDP_BUFFER)
	#define SD_BUFFER_SIZE BUFFER1_UDP_LEN
#else
	#define SD_BUFFER_SIZE 512
#endif

#define INTERRUPT

/* Work register for fs command */
extern DWORD acc_size;			
extern WORD acc_files, acc_dirs;
extern FILINFO Finfo;
extern DIR dirs;
extern FIL file1;			/* This is the File object */
extern unsigned int* buff_read;
extern unsigned int  readCount;
extern unsigned int* buff_write;
extern unsigned int  writeCount;
extern FRESULT file_rep;
#if _USE_LFN
extern char Lfname[512];
#endif

extern char Line[128];		/* Console input buffer */
extern FATFS Fatfs;			/* File system object for each logical drive */
extern BYTE buff[];		/* Working buffer */

extern volatile UINT Timer;	/* 1kHz increment timer */

extern volatile BYTE rtcYear, rtcMon, rtcMday, rtcHour, rtcMin, rtcSec;

extern void __attribute__((interrupt, auto_psv)) _T4Interrupt (void);
extern DWORD get_fattime (void);
extern void put_rc (FRESULT );

extern void AppDebug(char* txt);
extern FRESULT openFileSD(char* filename, BYTE mode);
extern FRESULT closeFileSD(void);
extern FRESULT writeFileSD(char* text);
extern FRESULT readFileSD(DWORD toRead);
extern FRESULT listFileSD(char* path, BOOL recursivePath);
extern FRESULT seekFileSD(DWORD offset);

#endif //_FATFSHELPER
